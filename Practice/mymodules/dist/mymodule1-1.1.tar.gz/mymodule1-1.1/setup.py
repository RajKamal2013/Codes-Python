from setuptools import setup

setup(
		name='mymodule1',
		version='1.1',
		description='Practicing python and webapp',
		author='Raj Kamal',
		author_email='rajkamal2013@gmail.com',
		url='rajkamal2013@wordpress.com',
		py_modules=['mymodule1', 'athletelist']
		)
