Module Name :- 
	1.mymodule1.py
Functions :- 
	1.Search4Vowels(word:str='rajkamal') -> set :
	""" This function find out vowels present in word !"""

	2.Search4Letters(phrase:str = 'rajkamal', letters:str='aeiou') -> set :
	""" This function find out letters present in phrase

	3.Speak4Time():
	""" This will tell time is odd or even"""
Installation :- 
	sudo python3 -m pip install mymodule1
Uinstallation :- 
	python3 -m pip uninstall mymodule1
